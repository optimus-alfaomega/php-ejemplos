# CarAtYourService.com
I individually developed this project for university purporse.
Hritik Maheshwari
github : hritik21
B.Tech , SVVV
@all rights reserved.
To run this project 
-use XAMPP
-copy and paste all files in c://xampp//htdocs
-start apache and MySQL in xampp control panel
-open any browser 
- type localhost/dbcreation.php in url section in order to create database named "UserInformation" in your local server.
-type localhost/table.php in order to create table named "registerhere" in existing database .
- To look all this you can open phpmyadmin for this you need to type "localhost/phpmyadmin" in url section of browser.
- Now you are all set 
-To run this web application type "localhost/carrental.php" in url section of browser . This will bring you to the homepage of application.

Thankyou.
