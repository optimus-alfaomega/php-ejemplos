<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="carrental.css">
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>
<body>
<div class="navbar">
<a href="carrental.php">Home</a>
<a href="tarrif.php">Tarrifs</a>
<a href="#">About us</a>
<a href="#">Contact us</a>
<a href="login.php" class="right">Login</a>
<a href="registration.php" class="right">Sign Up</a>
</div>
<div class="bg-image"></div>


<div class="bg-text">
 
<div class="header">
  <h1>CarAtYourService.com</h1>
  <p>Book anytime for anywhere</p>
  <button class="button"><a href="login.php"/><span>Start Your wonderful Journey</span></button>
</div>

 
 
  
  
  </div>
</div>



</body>
</html>

</div>


