<html>
<head>
<link rel="stylesheet" href="carrental.css">

</head>
<body>
<div class="navbar">
  <a href="carrental.php">Home</a>
  <a href="tarrif.php">Tarrifs</a>
  <a href="#">About us</a>
  <a href="#">Contact us</a>
  <a href="login.php" class="right">Login</a>
  <a href="registration.php" class="right">Sign Up</a>
</div>

<pre>


<div class="bg-image"></div>


<div class="bg-text">
<form method="post" action = "session.php">
Username : <input type = "text" name="uname" placeholder="abc@xyz.com">

Password : <input type = "password" name="pwd">

<input type = "submit" value="Sign Up" name="submit">
</form>
 
<div class="header">
 
</div>

 
 
  
  
  </div>
</div>


</body>
</html>