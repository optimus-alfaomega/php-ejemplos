<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="carrental.css">
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>
<body>
<div class="navbar">
<a href="carrental.php">Home</a>
<a href="#">Tarrifs</a>
<a href="#">About us</a>
<a href="#">Contact us</a>
<a href="login.php" class="right">Login</a>
<a href="registration.php" class="right">Sign Up</a>
</div>
<div class="bg-image"></div>


<div class="bg-text">
 
<div class="header">
 
 <?php  ?>
<center>
<table border>
    <tr>
        <th>Cost (INR)</th>
        <th>Distance (KMs)</th>
    </tr>
<tr>
        <th><50</th>
        <td>700</td>
    </tr>
<tr>
    <th>50 - 100</th>
        <td>1500</td>
    </tr>
<tr>
        <th>100 - 150</th>
        <td>2000</td>
    </tr>
<tr>
        <th>For each Extra KM</th>
        <td>50</td>
    </tr>

</table><br>
! Tolls are not included in the payment and are to be payed by the customer itself
<br>
<table>
    <tr>
        In case you need a driver
    </tr>
    <tr>
        <th>per day</th>
        <th>200 INR</th>
    </tr>
    
</table>! In case the driver misbehaves call us 
</center>
 
 
</div>

 
 
  
  
  </div>
</div>



</body>
</html>

</div>


