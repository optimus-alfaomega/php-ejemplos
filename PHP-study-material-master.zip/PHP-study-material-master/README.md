## Study-material

- [PHP Document](http://php.net/manual/en/)
- [Session](https://www.sitepoint.com/php-sessions/)

- [Login and Signup Form](https://www.tutorialrepublic.com/php-tutorial/php-mysql-login-system.php)

- [Store and display image from mysql](http://raynux.com/blog/2008/11/20/store-and-display-image-from-mysql-database/)
- [Uploading file as blob](https://www.codexworld.com/store-retrieve-image-from-database-mysql-php/)
- [Role based Login](https://prittytimes.com/secure-login-page-using-php-and-mysql-based-on-user-role/)
- [Prepared sql query for inserting blob](https://stackoverflow.com/questions/1747894/php-inserting-binary-data-in-mysql-using-prepared-statements/30019463#30019463)

