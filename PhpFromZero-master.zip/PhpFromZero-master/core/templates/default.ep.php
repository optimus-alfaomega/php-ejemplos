<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Default PhpFromZero Page</title>
</head>

<body>

    <h1>This is the default templates</h1>
    If you see this page, this is because you have not defined any templates in your templates/ folder or the given template by your controller cannot be found

    <h2>Provided by PhpFromZero || Justin Dah-kenangnon</h2>
</body>

</html>