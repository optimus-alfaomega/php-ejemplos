<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bad request</title>
</head>

<body style=" max-width: 500px;
  margin: auto;">
    <h1>Bad request</h1>
    Something is wrong in your request


    <h2>If you're this website developpeur, plus customize this page to fit your site design.</h2>

</body>

</html>