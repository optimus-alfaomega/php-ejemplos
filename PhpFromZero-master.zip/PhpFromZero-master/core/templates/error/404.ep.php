<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page not found</title>
</head>

<body style=" max-width: 500px;
  margin: auto;">

    <h1>This page is not found</h1>
    The page you're searching for is not found. <br>

    You can go forward to <a href="/"> the home page</a>

    <h2>If you're this website developpeur, plus customize this page to fit your site design.</h2>

</body>

</html>