<?php

namespace App\Services;



/**
 * An example of services
 * 
 * A service is used to modularize the code and make it reusable.
 * 
 * You can define any service you want for certain logic flow
 * 
 * @author Justin Dah-kenangnon <dah.kenangnon@gmail.com>
 * 
 * @link https://github.com/Dahkenangnon
 * @link https://ePatriote.com
 * @link https://LaSyntax.com
 * @link https://Dah-kenangnon.com
 */
class MessageService
{
    
}
