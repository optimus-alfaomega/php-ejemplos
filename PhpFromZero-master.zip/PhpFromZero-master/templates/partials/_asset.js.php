<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>


<!-- Core theme JS-->
<script src="<?= $ep_base_dir ?>js/scripts.js"></script>