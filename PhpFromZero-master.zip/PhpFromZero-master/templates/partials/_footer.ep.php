<footer class="bg-primary footer">
    <div class="container">
        <p class="m-0 text-center text-white">Code: https://github.com/Dahkenangnon/PhpFromZero
        <br>
        (c) <a class="text-white" href="https://dah-kenangnon.com">Justin Dah-kenangnon</a></p>
    </div>
</footer>