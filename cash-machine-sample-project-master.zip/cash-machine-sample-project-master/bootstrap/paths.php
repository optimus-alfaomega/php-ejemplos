<?php

define('SOURCE_PATH', dirname(PROJECT_PATH, 1) . '/_cashmachine_source');
define('CONFIG_PATH', PROJECT_PATH . '/configs/');
define('LOGGER_PATH', SOURCE_PATH . '/logs');
