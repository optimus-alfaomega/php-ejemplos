<?php

namespace CashMachine\Common\Domain\Contracts;

interface ModelInterface extends \JsonSerializable
{

}