<?php

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';
