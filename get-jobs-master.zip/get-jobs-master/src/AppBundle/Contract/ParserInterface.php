<?php

namespace AppBundle\Contract;

interface ParserInterface
{

}