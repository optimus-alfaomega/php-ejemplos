<div class="text-center">
	<h1 class="text-center">Are You Sure Want To Delete Your Account?</h1>
	<form method="post" action="" enctype="multipart/form-data">
		<input type="submit" name="yes" value="Yes, I Want To Delete It" class="btn btn-danger mr-2">
		<input type="submit" name="yes" value="No, I Dont Want To Keep It" class="btn btn-primary">
	</form>
</div>
