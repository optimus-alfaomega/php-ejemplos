<div class="text-center">
	<h1>Pay Offline Using Method</h1>
	<p class="text-muted border-bottom">if you have any question, please feel free to <a href="../contact.php">contact us</a>, our customers service center is working for you</p>
</div>
<div class="table-responsive">
	<table class="table table-bordered table-striped table-hover">
		<thead>
			<tr>
				<th>Bank Account Details</th>
				<th>Bank Cash Details</th>
				<th>Western Union Details</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Bank Name : BCA No:123-000987866 Branch Code : 012 Branch Name : KCP Asia</td>
				<td>NIK: 1207987612345678 Mobile: 081234567645 Name: Fulan FUlanta</td>
				<td>Full Name: Fulan Fulanta, Mobile: 081234567645, Country: Indonesia, </td>
			</tr>
		</tbody>
	</table><!-- table table-borderes table-responsive ends -->
</div><!-- table-responseive ends -->