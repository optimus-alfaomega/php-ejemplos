<div class="card sidebar-menu mb-4">
	<div class="card-header">
		<h5 class="card-title">Products Categories</h5>
	</div><!-- card-header ends-->
	<div class="card-body">
		<ul class="nav nav-pills flex-column nav-stacked category-menu">
			<li><a class="nav-link" href="shop.php"> Jackets</a></li>
			<li><a class="nav-link" href="shop.php">Accessories</a></li>
			<li><a class="nav-link" href="shop.php">Shoes</a></li>
			<li><a class="nav-link" href="shop.php">Coats</a></li>
			<li><a class="nav-link" href="shop.php">T-Shirts</a></li>
			<li><a class="nav-link" href="shop.php">Hats</a></li>
		</ul><!-- nav nav-pills nav-stacked category-menu ends -->
	</div><!-- card body ends -->
</div><!-- card sidebar-menu ends -->

<div class="card sidebar-menu">
	<div class="card-header">
		<h5 class="card-title">Categories</h5>
	</div><!-- card-header ends-->
	<div class="card-body">
		<ul class="nav nav-pills flex-column nav-stacked category-menu">
			<li><a class="nav-link" href="shop.php">Men</a></li>
			<li><a class="nav-link" href="shop.php">Women</a></li>
			<li><a class="nav-link" href="shop.php">Kids</a></li>
			<li><a class="nav-link" href="shop.php">Others</a></li>
		</ul><!-- nav nav-pills nav-stacked category-menu ends -->
	</div><!-- card body ends -->
</div><!-- card sidebar-menu ends -->